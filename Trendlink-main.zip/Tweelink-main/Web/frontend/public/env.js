window.env = {
  "BACKEND": "http://localhost:8000"
};