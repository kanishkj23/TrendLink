- Gensim Documentation
	- https://radimrehurek.com/gensim//auto_examples/index.html

- Soft Cosine Similarity:
	- https://radimrehurek.com/gensim//auto_examples/tutorials/run_scm.html#sphx-glr-auto-examples-tutorials-run-scm-py

- Word2Vec Model:
	- https://radimrehurek.com/gensim//auto_examples/tutorials/run_word2vec.html#sphx-glr-auto-examples-tutorials-run-word2vec-py

- Top n terms with TF IDF score
	- https://stackoverflow.com/questions/34232190/scikit-learn-tfidfvectorizer-how-to-get-top-n-terms-with-highest-tf-idf-score

- BM25 (Java)
	- http://haifengl.github.io/api/java/smile/nlp/relevance/BM25.html

- Binary Independence Model
	- https://github.com/laurabalasso/Binary-Independence-Model-